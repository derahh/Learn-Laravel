@extends('base') {{-- mengambil file base.blade.php --}}
@section('content') {{-- Mengisi di bagian content --}}
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h1>Latihan API</h1>

            <h3>Halo, ini adalah halaman kedua!</h3>
        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
@endsection