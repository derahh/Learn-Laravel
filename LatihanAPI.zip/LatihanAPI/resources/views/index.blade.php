@extends('base')
@section('content')
    <!-- Main Section -->
    <section class="main-section">
        <!-- Add Your Content Inside -->
        <div class="content">
            <!-- Remove This Before You Start -->
            <h1>Tutorial Laravel 5.4</h1>
            <p>Apa saja yang akan kamu pelajari ?</p>

            <h2>* Templating Laravel 5.4</h2>
            <h2>* CRUD dengan Laravel 5.4</h2>
            <h2>* Upload Image dengan laravel 5.4 (Soon)</h2>
            <h2>* Login & Register dengan Auth & Session built in Laravel 5.4 (Soon)</h2>
            <h2>* Kirim E-mail dengan Laravel 5.4 (Soon)</h2>
            <h2>* Basic Web Service dengan Laravel 5.4 (Soon)</h2>
            <h2>* Laravel OAuth 2.0 dengan Laravel Passport 5.4 (Soon)</h2>
            <h2>* Perkenalan dengan Lumen (Microframework Laravel untuk REST API) (Soon)</h2>
        </div>
        <!-- /.content -->
    </section>
    <!-- /.main-section -->
@endsection